/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryabb;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author PcUser
 */
public class Person implements Serializable {

    private int id;
    private String name;
    private Date d1;
    private String address;

    public Person(int id, String name, Date d1, String address) {
        this.id = id;
        this.name = name;
        this.d1 = d1;
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getD1() {
        return d1;
    }

    public void setD1(Date d1) {
        this.d1 = d1;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInfo() {
        return "id: " + this.getId() + ",name: " + this.getName() + "date: " + this.getD1().getDay() + "/"
                + this.getD1().getMonth() + "/" + this.getD1().getYear() + ", address :" + this.getAddress();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Person person = (Person) obj;
        if (!this.address.equals(person.name)) {
            return false;
        }
        if (this.id != person.id) {
            return false;
        }
        if (this.name.equals(person.name)) {
            return false;
        }
        if (this.d1 != person.d1) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + this.id;
        hash = 29 * hash + Objects.hashCode(this.name);
        hash = 29 * hash + Objects.hashCode(this.d1);
        hash = 29 * hash + Objects.hashCode(this.address);
        return hash;
    }

}
