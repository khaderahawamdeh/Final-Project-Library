/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryabb;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Utils {

    public static void serializeBooks(ArrayList<Book> books) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("books.dat");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);

            objectOutputStream.writeObject(books);
            System.out.println("Books collection serialized successfully");
            objectOutputStream.close();
        } catch (IOException e) {
            System.out.println("Error during serialization " + e.getMessage());
        }
    }

    public static ArrayList<Book> deserializeBooks() {

        ArrayList<Book> books = new ArrayList<>();
        File file = new File("books.dat");

        if (!file.exists()) {
            return books;
        }

        try {

            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

            books = (ArrayList<Book>) objectInputStream.readObject();
            System.out.println("Books collection deserialized successfully.");

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error during deserialization " + e.getMessage());
        }
        return books;
    }
}
